# Guide to Pāli — Website Source

A step-by-step interactive Pāli learning website based on the *Pāli Primer* by Lily de Silva (Vipassana Research Institute, 1991).

## Files

| File | Description |
|------|-------------|
| `index.html` | Landing page — hero, intro, lesson grid preview, alphabet strip, CTA |
| `lessons.html` | Lesson index — all 32 lessons with filter, search, list/grid view, progress panel |
| `lesson-1.html` | Lesson I — The Nominative Case (full lesson: grammar, vocab, examples, exercises) |

## How to use

Open any file directly in a browser — no server required. All fonts load from Google Fonts (internet connection needed for fonts).

### Navigation links
- `index.html` → links to `lessons.html` and `lesson-1.html`
- `lessons.html` → links back to `index.html`
- `lesson-1.html` → links to `index.html` and `lessons.html`

## Still to build (Steps 4–6)
- `practice.html` — AI-powered sentence practice (Claude API)
- `alphabet.html` — Interactive Pāli alphabet with phonetics
- `vocabulary.html` — Searchable full glossary

## Design
- **Fonts:** Cormorant Garamond (headings), Lora (body)
- **Palette:** Parchment cream · Saffron ochre · Bodhi red · Deep ink
- **Aesthetic:** Ancient manuscript meets refined editorial
